﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace homeworkQ1Text4._22OhadCohen
{
    public class User
    {
        private string email;
        private string fullName;
        private int age;

        /*constructor*/
        public User(string email, string fullName, int age)
        {
            this.email = email;
            this.fullName = fullName;
            this.age = age;
        }

        /*Getters and Setters*/
        public String getEmail()
        {
            return email;
        }
        public void setEmail(String Email)
        {
            email = Email;
        }
        public String getFullName()
        {
            return fullName;
        }
        public void setFullName(String fullName)
        {
            this.fullName=fullName;
        }
        public int getAge()
        {
            return age;
        }
        public void setAge(int age)
        {
            this.age = age;
        }

        /*toString method*/
        public String toString()
        {
            return "User: " + email + " fullName: " + fullName + " age: " + age;
        }

        

    }
}