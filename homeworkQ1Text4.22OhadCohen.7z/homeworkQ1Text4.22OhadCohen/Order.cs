﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace homeworkQ1Text4._22OhadCohen
{
    public class Order
    {
        private int id;
        private List<String> productsInOrder;
        private String emailPersonOrdered;

        /*constructor*/
        public Order(int id, List<String> productsInOrder, string emailPersonOrdered)
        {
            this.id = id;
            this.productsInOrder = productsInOrder;
            this.emailPersonOrdered = emailPersonOrdered;
        }

        /*Getters and Setters*/
        public int getId()
        {
            return id;
        }
        public void setId(int id)
        {
            this.id = id;
        }
        public List<String> getProductsInOrder()
        {
            return productsInOrder;
        }
        public void setProductsInOrder(List<String> productsInOrder)
        {
            this.productsInOrder = productsInOrder;
        }
        public String getEmailPersonOrdered()
        {
            return emailPersonOrdered;
        }
        public void setEmailPersonOrdered(String emailPersonOrdered)
        {
            this.emailPersonOrdered = emailPersonOrdered;
        }

        /*This method is meant for printing productsInOrder*/
        public void printProductsInOrder()
        {
            foreach(String p in productsInOrder)
            {
                Console.WriteLine(p);
            }
        }
        /*toString method*/
        public String toString()
        {
            printProductsInOrder();
            return "Order: " + id  + " emailPersonOrdered: " + emailPersonOrdered;
        }
    }
}