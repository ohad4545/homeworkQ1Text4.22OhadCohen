﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*This singleton class meant for keeping the whole data of the system(was written manually at the code) */
namespace homeworkQ1Text4._22OhadCohen
{
    internal class Data
    {
        private static Data single_instance = null;
        public List<User> Users;
        public List<Order> Orders;

        // Constructor singleton class
        private Data()
        {
            
        }

        public static Data getInstance()
        {
            if (single_instance == null)
                single_instance = new Data();

            return single_instance;
        }
        

        public void initUsers()
        { 
            Users = new List<User>();

            Users.Add(new User("avi.ron@gmail.com","Avi Ron",42));
            Users.Add(new User("miki.peli@gmail.com", "Miki Peli", 29));
            Users.Add(new User("beri.zakala@gmail.com", "Beri Zakala", 26));
        }
        public void initOrders()
        {
            Orders = new List<Order>();

            List<String> tmp1 = new List<String>();
            tmp1.Add("Wine");tmp1.Add("bread");tmp1.Add("cheese");
            Orders.Add(new Order(1, tmp1, "avi.ron@gmail.com"));

            List<String> tmp2 = new List<String>();
            tmp2.Add("pasta"); tmp2.Add("beef"); tmp2.Add("tomato sauce");
            Orders.Add(new Order(2, tmp2, "avi.ron@gmail.com"));

            List<String> tmp3 = new List<String>();
            tmp3.Add("ice cream"); tmp3.Add("chocolate"); tmp3.Add("milk");
            Orders.Add(new Order(3, tmp3, "miki.peli@gmail.com"));
        }

        public void initData()
        {
            initUsers();
            initOrders();
        }
    }

}
