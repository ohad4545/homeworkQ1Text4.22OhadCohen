﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*This program meant for running basic SQL queries*/
/*pay attantion: The atrributes of the User class and the Order class start with lowercase letters*/
namespace homeworkQ1Text4._22OhadCohen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Data.getInstance().initData();
            List<String> searchQuery = getSearchQuery();
            runSearch(searchQuery);
        }

        /*This function gets the SQL query from the user and returns it, seperated by "from" phrash, "where" phrase and "select" phrase*/
        private static List<String> getSearchQuery()
        {
            Console.WriteLine("Please type your search query here at fromat:\nfrom...\nwhere...\nselect...\neach command(from,where,select) at a different line: ");
            String q1, q2, q3;
            q1 = Console.ReadLine();
            q2 = Console.ReadLine();
            q3 = Console.ReadLine();
            List<String> list = new List<String>();
            list.Add(q1); list.Add(q2); list.Add(q3);
            return list;
        }

        private static void runSearch(List<String> searchQuery)
        {
            String from, where, select;
            int i;
            bool flag = false;

            /*format query checking*/
            while (flag == false)
            {
                if (searchQuery[2].ToLower().IndexOf("select") == -1 || searchQuery[1].ToLower().IndexOf("where") == -1
                    || searchQuery[0].ToLower().IndexOf("from") == -1)
                {
                    Console.WriteLine("please write your query at the fit format");
                    searchQuery = getSearchQuery();
                }

                else
                {
                    flag = true;
                }
            }

            /*from filtering*/
            from = searchQuery[0].Substring(5, searchQuery[0].Length - 5);
            from = from.Trim();

            /*where filtering*/
            where = searchQuery[1].Substring(6, searchQuery[1].Length - 6);

            /*lowercase the "and"*/
            if (where.ToLower().IndexOf(" and ") != -1)
            {
                where = where.Substring(0, where.ToLower().IndexOf(" and "))+
                        " and "+
                        where.Substring(where.ToLower().IndexOf(" and ") + 5,where.Length - 
                        (where.ToLower().IndexOf(" and ") + 5));
            }

            /*lowercase the "or"*/
            if (where.ToLower().IndexOf(" or ") != -1)
            {
                where = where.Substring(0, where.ToLower().IndexOf(" or ")) +
                        " or "+
                        where.Substring(where.ToLower().IndexOf(" or ") + 4, where.Length -
                        (where.ToLower().IndexOf(" or ") + 4));
            }

            /*select filtering*/
            select = searchQuery[2].Substring(7, searchQuery[2].Length - 7);



            /* from handling case 1: users table*/
            if (from.Equals("users"))
            {
                List<User> usersClone = new List<User>(Data.getInstance().Users);

                /*where handling case 1:split to And/Or expressions(assumtion:"And" is prior to "or")*/
                
                /*only "and"*/
                if(where.ToLower().IndexOf(" and ") != -1 && where.ToLower().IndexOf(" or ") == -1)
                {
                    if (where.IndexOf("(") != -1)
                    {
                        where = where.Trim();
                        where = where.Trim('(',')');
                    }
                    usersClone = ConditionSplit("and", usersClone, where);
                }

                /*only "or"*/
                else if (where.ToLower().IndexOf(" and ") == -1 && where.ToLower().IndexOf(" or ") != -1)
                {
                    if (where.IndexOf("(") != -1)
                    {
                        where = where.Trim();
                        where = where.Trim('(', ')');
                    }
                    usersClone = ConditionSplit("or", usersClone, where);
                }

                /*no "AND" && no "or"*/
                else if (where.ToLower().IndexOf(" and ") == -1 && where.ToLower().IndexOf(" or ") == -1)
                {
                    if (where.IndexOf("(") != -1)
                    {
                        where = where.Trim();
                        where = where.Trim('(', ')');
                    }
                    usersClone = ConditionSplit("or", usersClone, where);//can also get "and" string at the function
                }

                else//where has "AND" and "OR"
                {
                    /*assumtion: expression inside is () prior to "AND" && "or"*/

                    /*where (... or ...) and ... case*/
                    if (where.IndexOf('(') < where.IndexOf(" or ") && 
                        where.IndexOf(')') > where.IndexOf(" or "))
                    {
                        String[] conditionSeperator = { "(", ")" };
                        String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);
                        for (i = 0; i < conditionWhereArr.Length; i++)
                        {
                            if (conditionWhereArr[i].ToLower().IndexOf(" or ") != -1)
                            {
                                List<User> usersClone2 = new List<User>(Data.getInstance().Users);
                                usersClone = ConditionSplit("or", usersClone, conditionWhereArr[i]);
                                if (i == 0)
                                {
                                    usersClone2 = ConditionSplit("and", usersClone2, conditionWhereArr[1]);
                                }
                                else if (i == 1)
                                {
                                    usersClone2 = ConditionSplit("and", usersClone2, conditionWhereArr[0]);
                                }
                                
                                /*cutting usersClone and usersClone2*/

                                List<User> usersClone3 = new List<User>();
                                for(int d=0;d<usersClone.Count;d++)
                                {
                                    for(int f=0;f<usersClone2.Count;f++)
                                    {
                                        if (usersClone[d].Equals(usersClone2[f]))//check if the address at the memory is the same of the 2 expressions compared
                                        {
                                            usersClone3.Add(usersClone[d]);
                                        }
                                    }
                                }
                                usersClone = usersClone3;
                            }
                        }
                    }

                    /*where (... and ...) or ... case*/
                    else if (where.IndexOf('(') < where.IndexOf(" and ") &&
                        where.IndexOf(')') > where.IndexOf(" and "))
                    {
                        String[] conditionSeperator = { "(", ")" };
                        String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);
                        for (i = 0; i < conditionWhereArr.Length; i++)
                        {
                            if (conditionWhereArr[i].ToLower().IndexOf(" and ") != -1)
                            {
                                List<User> usersClone2 = new List<User>(Data.getInstance().Users);
                                usersClone = ConditionSplit("and", usersClone, conditionWhereArr[i]);
                                if (i == 0)
                                {
                                    usersClone2 = ConditionSplit("or", usersClone2, conditionWhereArr[1]);
                                }
                                else if (i == 1)
                                {
                                    usersClone2 = ConditionSplit("or", usersClone2, conditionWhereArr[0]);
                                }

                                /*union usersClone and usersClone2*/
                                List<User> usersClone3 = new List<User>();
                                usersClone3 = usersClone.Union(usersClone2).ToList();
                                usersClone = usersClone3;
                            }
                        }
                    }
                    else //"And" && "Or" with no '(',')'
                    {
                        String[] conditionSeperator = { " or " };
                        String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);
                        for (i = 0;i<conditionWhereArr.Length;i++)
                        {
                            if(conditionWhereArr[i].IndexOf(" and ")!=-1)
                            {
                                List<User> usersClone2 = new List<User>(Data.getInstance().Users);
                                usersClone = ConditionSplit("and", usersClone, conditionWhereArr[i]);

                                if(i==0)
                                {
                                    usersClone2 = ConditionSplit("or", usersClone2, conditionWhereArr[1]);
                                }
                                else if (i == 1)
                                {
                                    usersClone2 = ConditionSplit("or", usersClone2, conditionWhereArr[0]);
                                }

                                /*union usersClone, usersClone2*/
                                List<User> usersClone3 = new List<User>();
                                usersClone3 = usersClone.Union(usersClone2).ToList();
                                usersClone = usersClone3;
                                
                            }
                        }
                    }
                }

                /*select from users table handling*/
                selectHandlingUsers(usersClone, select);
            }

            /*from case 2: orders table*/
            else if(from.Equals("orders"))
            {
                List<Order> ordersClone = new List<Order>(Data.getInstance().Orders);

                /*where handling case 1:split to And/Or expressions(assumtion:"And" is prior to "or")*/

                /*only "and"*/
                if (where.ToLower().IndexOf(" and ") != -1 && where.ToLower().IndexOf(" or ") == -1)
                {
                    if (where.IndexOf("(") != -1)
                    {
                        where = where.Trim();
                        where = where.Trim('(', ')');
                    }
                    ordersClone = ConditionSplit("and", ordersClone, where);
                }

                /*only "or"*/
                else if (where.ToLower().IndexOf(" and ") == -1 && where.ToLower().IndexOf(" or ") != -1)
                {
                    if (where.IndexOf("(") != -1)
                    {
                        where = where.Trim();
                        where = where.Trim('(', ')');
                    }
                    ordersClone = ConditionSplit("or", ordersClone, where);
                }

                /*no "AND" && no "or"*/
                else if (where.ToLower().IndexOf(" and ") == -1 && where.ToLower().IndexOf(" or ") == -1)
                {
                    if (where.IndexOf("(") != -1)
                    {
                        where = where.Trim();
                        where = where.Trim('(', ')');
                    }
                    ordersClone = ConditionSplit("or", ordersClone, where);//can also get "and" string at the function
                }

                else//where has "AND" and "OR"
                {
                    /*assumtion: expression inside is () prior to "AND" && "or"*/

                    /*where (... or ...) and ... case*/
                    if (where.IndexOf('(') < where.IndexOf(" or ") &&
                        where.IndexOf(')') > where.IndexOf(" or "))
                    {
                        String[] conditionSeperator = { "(", ")" };
                        String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);
                        for (i = 0; i < conditionWhereArr.Length; i++)
                        {
                            if (conditionWhereArr[i].ToLower().IndexOf(" or ") != -1)
                            {
                                List<Order> ordersClone2 = new List<Order>(Data.getInstance().Orders);
                                ordersClone = ConditionSplit("or", ordersClone, conditionWhereArr[i]);
                                if (i == 0)
                                {
                                    ordersClone2 = ConditionSplit("and", ordersClone2, conditionWhereArr[1]);
                                }
                                else if (i == 1)
                                {
                                    ordersClone2 = ConditionSplit("and", ordersClone2, conditionWhereArr[0]);
                                }

                                /*cutting ordersClone, ordersClone2*/
                                List<Order> ordersClone3 = new List<Order>();
                                for (int d = 0; d < ordersClone.Count; d++)
                                {
                                    for (int f = 0; f < ordersClone2.Count; f++)
                                    {
                                        if (ordersClone[d].Equals(ordersClone2[f]))//check if the address at the memory is the same of the 2 expressions compared
                                        {
                                            ordersClone3.Add(ordersClone[d]);
                                        }
                                    }
                                }
                                ordersClone = ordersClone3;
                            }
                        }
                    }

                    /*where (... and ...) or ...*/
                    else if (where.IndexOf('(') < where.IndexOf(" and ") &&
                        where.IndexOf(')') > where.IndexOf(" and "))
                    {
                        String[] conditionSeperator = { "(", ")" };
                        String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);
                        for (i = 0; i < conditionWhereArr.Length; i++)
                        {
                            if (conditionWhereArr[i].ToLower().IndexOf(" and ") != -1)
                            {
                                List<Order> ordersClone2 = new List<Order>(Data.getInstance().Orders);
                                ordersClone = ConditionSplit("and", ordersClone, conditionWhereArr[i]);
                                if (i == 0)
                                {
                                    ordersClone2 = ConditionSplit("or", ordersClone2, conditionWhereArr[1]);
                                }
                                else if (i == 1)
                                {
                                    ordersClone2 = ConditionSplit("or", ordersClone2, conditionWhereArr[0]);
                                }

                                /*union ordersClone,ordersClone2*/
                                List<Order> ordersClone3 = new List<Order>();
                                ordersClone3 = ordersClone.Union(ordersClone2).ToList();
                                ordersClone = ordersClone3;
                            }
                        }
                    }

                    /*"And" && "or" with no '(',')'*/
                    else
                    {
                        String[] conditionSeperator = { " or " };
                        String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);
                        for (i = 0; i < conditionWhereArr.Length; i++)
                        {
                            if (conditionWhereArr[i].IndexOf(" and ") != -1)
                            {
                                List<Order> ordersClone2 = new List<Order>(Data.getInstance().Orders);
                                ordersClone = ConditionSplit("and", ordersClone, conditionWhereArr[i]);

                                if (i == 0)
                                {
                                    ordersClone2 = ConditionSplit("or", ordersClone2, conditionWhereArr[1]);
                                }
                                else if (i == 1)
                                {
                                    ordersClone2 = ConditionSplit("or", ordersClone2, conditionWhereArr[0]);
                                }

                                /*union ordersClone,ordersClone2*/
                                List<Order> ordersClone3 = new List<Order>();
                                ordersClone3 = ordersClone.Union(ordersClone2).ToList();
                                ordersClone = ordersClone3;
                            }
                        }
                    }
                }

                /*select from orders table handling*/
                selectHandlingOrders(ordersClone, select);
            }

            /*Source does not exist*/
            else
            {
                Console.WriteLine("Source does not exist");
                printMistakeMessage();
            }

            Console.WriteLine("Type any button and then press 'enter' to finish the program's running");
            Console.ReadLine();
        }

        /*This function meant for :"select" phrase handling orders table*/
        private static void selectHandlingOrders(List<Order> ordersClone, string select)
        {
            String[] commaSeperator = { ","," ,",", " };
            String[] selectSeperator = select.Split(commaSeperator, StringSplitOptions.RemoveEmptyEntries);
            Console.WriteLine("Results:");
            for (int i = 0; i < ordersClone.Count; i++)
            {
                for (int j = 0; j < selectSeperator.Length; j++)
                {
                    selectSeperator[j] = selectSeperator[j].Trim();

                    if (selectSeperator[j].Equals("id"))
                        Console.Write(ordersClone[i].getId() + " ");
                    else if (selectSeperator[j].Equals("productsInOrder"))
                    {
                        Console.Write("productsInOrder: ");
                        for(int l = 0; l < ordersClone[i].getProductsInOrder().Count;l++)
                        {
                            Console.Write(ordersClone[i].getProductsInOrder()[l] + " ");
                        }
                        
                    }
                    else if (selectSeperator[j].Equals("emailPersonOrdered"))
                    {
                        Console.Write(ordersClone[i].getEmailPersonOrdered() + " ");
                    }

                    /*illegal field*/
                    else
                    {
                        Console.WriteLine("Illegal field");
                        printMistakeMessage();
                    }
                }
                Console.WriteLine();
            }
        }

        /*This function meant for filltering the results by the input of "where" phrase, dealing with orders table field*/
        private static List<Order> ConditionSplit(string condition, List<Order> ordersClone, string where)
        {
            String[] conditionSeperator = { " " + condition + " " };
            List<Order> ordersCloneOrCondition = new List<Order>();
            List<Order> ordersToRemove = new List<Order>();
            String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < conditionWhereArr.Length; i++)
            {
                conditionWhereArr[i] = conditionWhereArr[i].Trim();
                String[] operatorSeperator = { ">", "<", "=" };
                String[] operatorWhereArr = conditionWhereArr[i].Split(operatorSeperator, StringSplitOptions.RemoveEmptyEntries);
                String queryOperator = "";
                int k;

                if (conditionWhereArr[i].Trim().Equals(""))
                    continue;
                /*find the operator at this part of the query*/

                for (k = operatorWhereArr[0].Length; conditionWhereArr[i].ElementAt<char>(k) != '>' &&
                    conditionWhereArr[i].ElementAt<char>(k) != '<' && conditionWhereArr[i].ElementAt<char>(k) != '='; k++) ;
                if (conditionWhereArr[i].ElementAt<char>(k + 1) == '=')
                {
                    queryOperator = conditionWhereArr[i].ElementAt<char>(k).ToString() + conditionWhereArr[i].ElementAt<char>(k + 1).ToString();
                }
                else
                {
                    queryOperator = conditionWhereArr[i].ElementAt<char>(k).ToString();
                }

                operatorWhereArr[0] = operatorWhereArr[0].Trim();
                operatorWhereArr[1] = operatorWhereArr[1].Trim();

                /*delete "" or '' of the expression(needed for cases like input: where fullName="Avi Ron")*/
                if (operatorWhereArr[1].StartsWith("\"") || operatorWhereArr[1].StartsWith("'"))
                {
                    operatorWhereArr[1] = operatorWhereArr[1].Substring(1, operatorWhereArr[1].Length - 2);
                }

                /*"=" case*/
                if (queryOperator.Equals("="))
                {
                    /*emailPersonOrdered case*/
                    if (operatorWhereArr[0].Equals("emailPersonOrdered"))
                    {
                        for (k = 0; k < ordersClone.Count; k++)
                        {
                            if (condition.Equals("and"))
                            {
                                if (!ordersClone[k].getEmailPersonOrdered().Equals(operatorWhereArr[1]))
                                {
                                    if (!ordersToRemove.Contains(ordersClone[k]))
                                        ordersToRemove.Add(ordersClone[k]);
                                }
                            }
                            else if (condition.Equals("or"))
                            {
                                if (ordersClone[k].getEmailPersonOrdered().Equals(operatorWhereArr[1]))
                                {
                                    if (!ordersCloneOrCondition.Contains(ordersClone[k]))
                                        ordersCloneOrCondition.Add(ordersClone[k]);
                                }
                            }
                        }
                    }

                    /*id case*/
                    else if (operatorWhereArr[0].Equals("id"))
                    {
                        try
                        {
                            for (k = 0; k < ordersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (ordersClone[k].getId() != Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersToRemove.Contains(ordersClone[k]))
                                            ordersToRemove.Add(ordersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (ordersClone[k].getId() == Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersCloneOrCondition.Contains(ordersClone[k]))
                                            ordersCloneOrCondition.Add(ordersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumnetNullException or FormatException at where phrase");
                            printMistakeMessage();
                        }
                    }
                    /*Invalid field*/
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*">" case*/
                if (queryOperator.Equals(">"))
                {
                    /*emailPersonOrdered case*/
                    if (operatorWhereArr[0].Equals("emailPersonOrdered"))
                    {
                        printMistakeMessage();
                    }

                    /*id case*/
                    else if (operatorWhereArr[0].Equals("id"))
                    {
                        try
                        {
                            for (k = 0; k < ordersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (ordersClone[k].getId() <= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersToRemove.Contains(ordersClone[k]))
                                            ordersToRemove.Add(ordersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {

                                    if (ordersClone[k].getId() > Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersCloneOrCondition.Contains(ordersClone[k]))
                                            ordersCloneOrCondition.Add(ordersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumentNullException or FormatException at where phrase");
                            printMistakeMessage();
                        }

                    }
                    /*illegal field*/
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*"<" case*/
                if (queryOperator.Equals("<"))
                {
                    /*emailPersonOrdered case*/
                    if (operatorWhereArr[0].Equals("emailPersonOrdered"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }

                    /*id case*/
                    else if (operatorWhereArr[0].Equals("id"))
                    {
                        try
                        {
                            for (k = 0; k < ordersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (ordersClone[k].getId() >= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersToRemove.Contains(ordersClone[k]))
                                            ordersToRemove.Add(ordersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (ordersClone[k].getId() < Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersCloneOrCondition.Contains(ordersClone[k]))
                                            ordersCloneOrCondition.Add(ordersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumentNullException or FormatException");
                            printMistakeMessage();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*">=" case*/
                if (queryOperator.Equals(">="))
                {
                    /*emailPersonOrdered case*/
                    if (operatorWhereArr[0].Equals("emailPersonOrdered"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }

                    /*id case*/
                    else if (operatorWhereArr[0].Equals("id"))
                    {
                        try
                        {
                            for (k = 0; k < ordersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (ordersClone[k].getId() < Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersToRemove.Contains(ordersClone[k]))
                                            ordersToRemove.Add(ordersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (ordersClone[k].getId() >= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersCloneOrCondition.Contains(ordersClone[k]))
                                            ordersCloneOrCondition.Add(ordersClone[k]);
                                    }
                                }
                            }
                        
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumentNullException or FormatException at where phrase");
                            printMistakeMessage();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*"<=" case*/
                if (queryOperator.Equals("<="))
                {

                    /*emailPersonOrdered case*/
                    if (operatorWhereArr[0].Equals("emailPersonOrdered"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }

                    /*id case*/
                    else if (operatorWhereArr[0].Equals("id"))
                    {
                        try
                        {
                            for (k = 0; k < ordersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (ordersClone[k].getId() > Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersToRemove.Contains(ordersClone[k]))
                                            ordersToRemove.Add(ordersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (ordersClone[k].getId() <= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!ordersCloneOrCondition.Contains(ordersClone[k]))
                                            ordersCloneOrCondition.Add(ordersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumentNullException or FormatException at where phrase");
                            printMistakeMessage();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }
            }
            if (condition.Equals("and"))
            {
                int len = ordersToRemove.Count;
                while (len > 0)
                {
                    ordersClone.Remove(ordersToRemove[len - 1]);
                    len--;
                }
                return ordersClone;
            }

            return ordersCloneOrCondition;
        }

        /*This function meant for filtering "where" phrase input,dealing with users table fields*/
        private static List<User> ConditionSplit(string condition, List<User> usersClone, String where)
        {
            String[] conditionSeperator = { " "+ condition+ " "};
            List<User> usersCloneOrCondition = new List<User>();
            List<User> usersToRemove = new List<User>();
            String[] conditionWhereArr = where.Split(conditionSeperator, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < conditionWhereArr.Length; i++)
            {
                String[] operatorSeperator = { ">", "<", "=" };
                String[] operatorWhereArr = conditionWhereArr[i].Split(operatorSeperator, StringSplitOptions.RemoveEmptyEntries);
                String queryOperator = "";
                int k;

                if (conditionWhereArr[i].Trim().Equals(""))
                    continue;

                /*find the operator at this part of the query*/
                for (k = operatorWhereArr[0].Length; conditionWhereArr[i].ElementAt<char>(k) != '>' &&
                    conditionWhereArr[i].ElementAt<char>(k) != '<' && conditionWhereArr[i].ElementAt<char>(k) != '='; k++) ;
                if (conditionWhereArr[i].ElementAt<char>(k + 1) == '=')
                {
                    queryOperator = conditionWhereArr[i].ElementAt<char>(k).ToString() + conditionWhereArr[i].ElementAt<char>(k + 1).ToString();
                }
                else
                {
                    queryOperator = conditionWhereArr[i].ElementAt<char>(k).ToString();
                }

                operatorWhereArr[0] = operatorWhereArr[0].Trim();
                operatorWhereArr[1] = operatorWhereArr[1].Trim();

                if (operatorWhereArr[1].StartsWith("\"") || operatorWhereArr[1].StartsWith("'"))
                {
                    operatorWhereArr[1] = operatorWhereArr[1].Substring(1, operatorWhereArr[1].Length - 2);
                }


                
                /*"=" case*/
                if (queryOperator.Equals("="))
                {
                    /*email case*/
                    if (operatorWhereArr[0].Equals("email"))
                    {
                        for (k = 0; k < usersClone.Count; k++)
                        {
                            if (condition.Equals("and"))
                            {
                                if (!usersClone[k].getEmail().Equals(operatorWhereArr[1]))
                                {
                                    if(!usersToRemove.Contains(usersClone[k]))
                                        usersToRemove.Add(usersClone[k]);
                                }
                            }
                            else if (condition.Equals("or"))
                            {
                                if (usersClone[k].getEmail().Equals(operatorWhereArr[1]))
                                {
                                    if(!usersCloneOrCondition.Contains(usersClone[k]))
                                        usersCloneOrCondition.Add(usersClone[k]);
                                }
                            }
                        }
                    }
                    /*fullName case*/
                    else if (operatorWhereArr[0].Equals("fullName"))
                    {
                        for (k = 0; k < usersClone.Count; k++)
                        {
                            if (condition.Equals("and"))
                            {
                                if (!usersClone[k].getFullName().Equals(operatorWhereArr[1]))
                                {
                                    if (!usersToRemove.Contains(usersClone[k]))
                                        usersToRemove.Add(usersClone[k]);
                                }
                            }
                            else if (condition.Equals("or"))
                            {
                                if (usersClone[k].getFullName().Equals(operatorWhereArr[1]))
                                {
                                    if (!usersCloneOrCondition.Contains(usersClone[k]))
                                        usersCloneOrCondition.Add(usersClone[k]);
                                }
                            }
                        }
                    }

                    /*age case*/
                    else if (operatorWhereArr[0].Equals("age"))
                    {
                        try
                        {
                            for (k = 0; k < usersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (usersClone[k].getAge() != Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersToRemove.Contains(usersClone[k]))
                                            usersToRemove.Add(usersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (usersClone[k].getAge() == Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersCloneOrCondition.Contains(usersClone[k]))
                                            usersCloneOrCondition.Add(usersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumentNullException or FormatException");
                            printMistakeMessage();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*">" case*/
                if (queryOperator.Equals(">"))
                {
                    /*email case*/
                    if (operatorWhereArr[0].Equals("email"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }
                    /*fullName case*/
                    else if (operatorWhereArr[0].Equals("fullName"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }

                    /*age case*/
                    else if (operatorWhereArr[0].Equals("age"))
                    {
                        try
                        {
                            for (k = 0; k < usersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (usersClone[k].getAge() <= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersToRemove.Contains(usersClone[k]))
                                            usersToRemove.Add(usersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {

                                    if (usersClone[k].getAge() > Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersCloneOrCondition.Contains(usersClone[k]))
                                            usersCloneOrCondition.Add(usersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumentNullException or FormatException at where phrase");
                            printMistakeMessage();
                        }


                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*"<" case*/
                if (queryOperator.Equals("<"))
                {
                    /*email case*/
                    if (operatorWhereArr[0].Equals("email"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }
                    /*fullName case*/
                    else if (operatorWhereArr[0].Equals("fullName"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }

                    /*age case*/
                    else if (operatorWhereArr[0].Equals("age"))
                    {
                        try
                        {
                            for (k = 0; k < usersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (usersClone[k].getAge() >= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersToRemove.Contains(usersClone[k]))
                                            usersToRemove.Add(usersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (usersClone[k].getAge() < Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersCloneOrCondition.Contains(usersClone[k]))
                                            usersCloneOrCondition.Add(usersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("ArgumentNullException or FormatException at where phrase");
                            printMistakeMessage();
                        }
                        
                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*">=" case*/
                if (queryOperator.Equals(">="))
                {
                    /*email case*/
                    if (operatorWhereArr[0].Equals("email"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }
                    /*fullName case*/
                    else if (operatorWhereArr[0].Equals("fullName"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }

                    /*age case*/
                    else if (operatorWhereArr[0].Equals("age"))
                    {
                        try
                        {
                            for (k = 0; k < usersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (usersClone[k].getAge() < Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersToRemove.Contains(usersClone[k]))
                                            usersToRemove.Add(usersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (usersClone[k].getAge() >= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersCloneOrCondition.Contains(usersClone[k]))
                                            usersCloneOrCondition.Add(usersClone[k]);
                                    }
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine("FormatException or ArgumentNullException at where phrase");
                            printMistakeMessage();
                        }
                        
                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }

                /*"<=" case*/
                if (queryOperator.Equals("<="))
                {
                    
                    /*email case*/
                    if (operatorWhereArr[0].Equals("email"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }
                    /*fullName case*/
                    else if (operatorWhereArr[0].Equals("fullName"))
                    {
                        Console.WriteLine("Invalid expression on where phrase");
                        printMistakeMessage();
                    }

                    /*age case*/
                    else if (operatorWhereArr[0].Equals("age"))
                    {
                        try 
                        {
                            for (k = 0; k < usersClone.Count; k++)
                            {
                                if (condition.Equals("and"))
                                {
                                    if (usersClone[k].getAge() > Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersToRemove.Contains(usersClone[k]))
                                            usersToRemove.Add(usersClone[k]);
                                    }
                                }
                                else if (condition.Equals("or"))
                                {
                                    if (usersClone[k].getAge() <= Int32.Parse(operatorWhereArr[1]))
                                    {
                                        if (!usersCloneOrCondition.Contains(usersClone[k]))
                                            usersCloneOrCondition.Add(usersClone[k]);
                                    }
                                }
                            }                       
                        }
                        catch(Exception e)//probably FormatException or ArgumentNullException
                        {
                            Console.WriteLine("FormatException or ArgumentNullException at where phrase");
                            printMistakeMessage();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid field on where phrase");
                        printMistakeMessage();
                    }
                }
            }
            if (condition.Equals("and"))
            {
                int len = usersToRemove.Count;
                while (len>0)
                {
                    usersClone.Remove(usersToRemove[len-1]);
                    len--;
                }
                return usersClone;
            }
                
            return usersCloneOrCondition;
        }

        /*This function meant for: select handling users table*/
        private static void selectHandlingUsers(List<User> usersClone, string select)
        {
            String[] commaSeperator = { ","," ,",", " };
            String[] selectSeperator = select.Split(commaSeperator, StringSplitOptions.RemoveEmptyEntries);
            Console.WriteLine("Results:");
            for (int i = 0; i < usersClone.Count; i++)
            {
                for (int j = 0; j < selectSeperator.Length; j++)
                {
                    selectSeperator[j] = selectSeperator[j].Trim();

                    if (selectSeperator[j].Equals("email"))
                        Console.Write(usersClone[i].getEmail() + " ");
                    else if (selectSeperator[j].Equals("fullName"))
                    {
                        Console.Write(usersClone[i].getFullName() + " ");
                    }
                    else if (selectSeperator[j].Equals("age"))
                    {
                        Console.Write(usersClone[i].getAge() + " ");
                    }
                    else
                    {
                        Console.WriteLine("Illegal field on select phrase");
                        printMistakeMessage();
                    }
                }
                Console.WriteLine();
            }
        }

        /*This function prints an error message when a error at the input happened and exit from the appliction*/
        private static void printMistakeMessage()
        {
            Console.WriteLine("There is a mistake in your query, please run the program again");
            System.Environment.Exit(0);
        }

    }
}


